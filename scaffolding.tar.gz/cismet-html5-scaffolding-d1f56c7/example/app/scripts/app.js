// main app module registration
angular.module(
    'de.cismet.myAngularApp',
    [
        'de.cismet.myAngularApp.controllers',
        'de.cismet.myAngularApp.directives',
        'de.cismet.myAngularApp.services'
    ]
);

