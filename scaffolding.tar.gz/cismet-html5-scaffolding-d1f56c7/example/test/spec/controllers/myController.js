'use strict';

describe('Controller: myController', function () {

  it('should do something', function () {
    expect(true).toBe(true);
  });

});
