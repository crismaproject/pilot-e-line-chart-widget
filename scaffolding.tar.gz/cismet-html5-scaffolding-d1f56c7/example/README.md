myAngularApp   
==============================

A simple example project that is actually buildable by the default build script.